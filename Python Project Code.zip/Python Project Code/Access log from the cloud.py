import boto3

def list_log_groups(session):
    logs_client = session.client('logs')
    
    try:
        response = logs_client.describe_log_groups()
        print("Available Log Groups:")
        for log_group in response['logGroups']:
            print(log_group['logGroupName'])
    except logs_client.exceptions.ClientError as e:
        print(f"An error occurred: {e}")

def list_log_streams(session, log_group_name):
    logs_client = session.client('logs')
    
    try:
        response = logs_client.describe_log_streams(logGroupName=log_group_name)
        print(f"Available Log Streams in '{log_group_name}':")
        for log_stream in response['logStreams']:
            print(log_stream['logStreamName'])
    except logs_client.exceptions.ResourceNotFoundException:
        print(f"Log group not found: {log_group_name}")
    except logs_client.exceptions.ClientError as e:
        print(f"An error occurred: {e}")

def main():
    # Create a session using the AWS credentials and region
    session = boto3.Session(
       aws_access_key_id='AKIA5FTY6WWEL47XUOPN',        # Replace with your AWS Access Key
        aws_secret_access_key='AYh1gvL802KlphUXuKwZTBCy5lw7Upy5diSK7y7h',# Replace with your AWS Secret Key
        region_name='ap-south-1'                      # Replace with your AWS region (e.g., 'us-west-2')
    )
    
    # List all log groups
    list_log_groups(session)
    
    log_group_name = input("Enter the log group name to list streams: ")
    
    # List all log streams within the specified log group
    list_log_streams(session, log_group_name)

if __name__ == "__main__":
    main()
