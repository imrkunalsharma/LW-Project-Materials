import boto3

myec2 = boto3.resource(
    service_name="ec2",
    region_name="ap-south-1",
    aws_access_key_id="AKIA5FTY6WWEL47XUOPN",
    aws_secret_access_key="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"

)

instances = myec2.create_instances(
    InstanceType="t2.micro",
    ImageId="ami-0ec0e125bb6c6e8ec",
    MaxCount=1,
    MinCount=1
)

print("Instances created:", instances)
