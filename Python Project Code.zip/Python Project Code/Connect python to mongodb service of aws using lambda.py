import pymongo
dbconn = pymongo.MongoClient("mongodb://127.0.0.1:27017")
dbconn.list_database_names()
dbname = dbconn["INIT"]
dbcollection = dbname["company1"]
dbcollection.find_one()
dbcollection.insert_one(
    {
        "cname": "Linux World",
        "location": "Jaipur"
    }
)
dbcollection.find()
for i in dbcollection.find({"cname": "Linux World"}):
    print(i)
