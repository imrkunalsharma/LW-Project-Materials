import boto3
from botocore.exceptions import NoCredentialsError, ClientError

def upload_to_s3(bucket_name, file_name, object_name=None):
    """
    Uploads a file to an S3 bucket.

    :param bucket_name: string
    :param file_name: string
    :param object_name: string
    :return: True if file was uploaded, else False
    """
    if object_name is None:
        object_name = file_name

    # Create an S3 client with hardcoded credentials (not recommended for production)
    s3_client = boto3.client(
        's3',
 aws_access_key_id=os.getenv('AKIA5FTY6WWEL47XUOPN'),
        aws_secret_access_key=os.getenv('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')
    )

    try:
        s3_client.upload_file(file_name, bucket_name, object_name)
    except FileNotFoundError:
        print(f"The file {file_name} was not found.")
        return False
    except NoCredentialsError:
        print("Credentials not available.")
        return False
    except ClientError as e:
        print(f"Failed to upload {file_name} to {bucket_name}. {e}")
        return False

    print(f"Successfully uploaded {file_name} to {bucket_name}/{object_name}.")
    return True

# Example usage
if __name__ == "__main__":
    bucket = 'kun-demo-bucket'  # Replace with your bucket name
    file_path = r'D:\hello.opus'  # Replace with the path to your file
    upload_to_s3(bucket, file_path)
